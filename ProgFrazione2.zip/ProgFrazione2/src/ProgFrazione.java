import java.util.Scanner;

public class ProgFrazione {

	static Frazione frazione1 = new Frazione();
	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {

		int num = 0;
		int den = 0;

		System.out.println("Inserisci un numeratore: ");
		
		try {
			num = Integer.parseInt(input.nextLine());
		} catch (NumberFormatException e) {
			System.out.println("Per piacere inserisci un numero!");
		}
		
		System.out.println("Inserisci un denominatore: ");

		do {
			try {
				den = Integer.parseInt(input.nextLine());
				if (den == 0) {
					System.out.println("Non puoi dividere per 0!");
				}
			} catch (NumberFormatException e) {
				System.out.println("Per piacere inserisci un numero!");
			} 
		} while (den==0);
		
		frazione1.setNum(num);
		frazione1.setDen(den);
		
		if(frazione1.getNum()!=0 && frazione1.getMin().getDen()!=1) {
		System.out.println(frazione1.getMin().toString());
		}
		else if(frazione1.getMin().getDen()==1) {
		System.out.println("Frazione: "+frazione1.getMin().getNum());
		}
		else
			System.out.println("Frazione: 0");
	}

}
